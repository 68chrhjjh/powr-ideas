# POWER IDEAS
## Setup
1. Create a Supabase project. In the SQL editor run `supabase/schema.sql`.
2. Create an admin: Auth → Users → Add user, then run:
   `update auth.users set raw_app_meta_data = raw_app_meta_data || '{"role":"admin"}' where email='you@example.com';`
3. `cp .env.example .env.local` and fill in the 3 Supabase values (service-role key is server-only).
4. Official logo is already in `public/logo.png` (trimmed of transparent margin only).
5. `npm install && npm run dev` (then `npm run build` to verify).
## Deploy (Vercel)
Import the repo, add the same 4 env vars, deploy. Set `NEXT_PUBLIC_SITE_URL` to the final URL.
## Status
Done: public site, likes (cookie + DB unique constraint + atomic SQL function), share, RLS, storage bucket, admin login guard, admin overview.
Not done: admin CRUD forms (creators/ideas/uploads/multi-select), search/filter/sort on /ideas, featured idea, cursor effects, parallax.
Interim content entry: Supabase Table Editor (rows) + Storage `images` bucket (copy public URL into `image_url`).
Rate limiting is per serverless instance only; use Upstash/Vercel KV for a durable limiter.
