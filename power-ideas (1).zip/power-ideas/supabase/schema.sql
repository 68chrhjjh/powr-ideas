-- Run in Supabase SQL editor.
create extension if not exists pgcrypto;
create table creators(id uuid primary key default gen_random_uuid(), name text not null, slug text unique not null,
  image_url text, channel_url text, description text, created_at timestamptz default now(), updated_at timestamptz default now());
create table ideas(id uuid primary key default gen_random_uuid(), title text not null, slug text unique not null,
  short_description text, full_description text, image_url text, category text,
  status text not null default 'draft' check (status in ('draft','published')),
  like_count int not null default 0, created_at timestamptz default now(), updated_at timestamptz default now());
create table idea_creators(idea_id uuid references ideas on delete cascade, creator_id uuid references creators on delete cascade, primary key(idea_id, creator_id));
create table idea_likes(id uuid primary key default gen_random_uuid(), idea_id uuid not null references ideas on delete cascade,
  visitor_id text not null, created_at timestamptz default now(), unique(idea_id, visitor_id));
create index on idea_creators(creator_id); create index on ideas(status, created_at desc);

alter table creators enable row level security; alter table ideas enable row level security;
alter table idea_creators enable row level security; alter table idea_likes enable row level security;
-- Admin = Supabase user whose app_metadata.role = 'admin' (set via SQL, see README).
create function is_admin() returns boolean language sql stable as $$ select coalesce(auth.jwt()->'app_metadata'->>'role','')='admin' $$;
create policy "public read creators" on creators for select using (true);
create policy "public read published ideas" on ideas for select using (status='published' or is_admin());
create policy "public read links" on idea_creators for select using (exists(select 1 from ideas i where i.id=idea_id and i.status='published') or is_admin());
create policy "admin all creators" on creators for all using (is_admin()) with check (is_admin());
create policy "admin all ideas" on ideas for all using (is_admin()) with check (is_admin());
create policy "admin all links" on idea_creators for all using (is_admin()) with check (is_admin());
-- idea_likes: no policies = only the service role (server) can touch it.

create function toggle_like(p_idea uuid, p_visitor text) returns table(out_liked boolean, out_count int)
language plpgsql security definer set search_path=public as $$
declare n int;
begin
  if not exists(select 1 from ideas where id=p_idea and status='published') then raise exception 'idea not found'; end if;
  delete from idea_likes where idea_id=p_idea and visitor_id=p_visitor;
  get diagnostics n = row_count;
  if n=0 then
    insert into idea_likes(idea_id,visitor_id) values(p_idea,p_visitor) on conflict do nothing;
    update ideas set like_count=like_count+1 where id=p_idea; out_liked:=true;
  else
    update ideas set like_count=greatest(like_count-1,0) where id=p_idea; out_liked:=false;
  end if;
  select like_count into out_count from ideas where id=p_idea;
  return next;
end $$;
revoke all on function toggle_like(uuid,text) from public, anon, authenticated;

insert into storage.buckets(id,name,public,file_size_limit,allowed_mime_types)
values('images','images',true,5242880,array['image/jpeg','image/png','image/webp']);
create policy "public read images" on storage.objects for select using (bucket_id='images');
create policy "admin write images" on storage.objects for all using (bucket_id='images' and is_admin()) with check (bucket_id='images' and is_admin());
