import { createClient } from '@supabase/supabase-js';
export const db = () => createClient(process.env.NEXT_PUBLIC_SUPABASE_URL!, process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY!, { auth: { persistSession: false } });
const IDEA_COLS = 'id,title,slug,short_description,image_url,category,like_count,created_at';
export async function getIdeas(limit?: number) {
  let q = db().from('ideas').select(IDEA_COLS).eq('status', 'published').order('created_at', { ascending: false });
  if (limit) q = q.limit(limit);
  return (await q).data ?? [];
}
export async function getCreators(limit?: number) {
  let q = db().from('creators').select('*, idea_creators(count)').order('created_at', { ascending: false });
  if (limit) q = q.limit(limit);
  return (await q).data ?? [];
}
export async function getCreator(slug: string) {
  const { data } = await db().from('creators').select(`*, idea_creators(ideas(${IDEA_COLS}))`).eq('slug', slug).maybeSingle();
  if (!data) return null;
  const ideas = (data.idea_creators as any[]).map((r) => r.ideas).filter(Boolean);
  return { ...data, ideas };
}
export async function getIdea(slug: string) {
  const { data } = await db().from('ideas').select('*, idea_creators(creators(*))').eq('slug', slug).eq('status', 'published').maybeSingle();
  if (!data) return null;
  return { ...data, creators: (data.idea_creators as any[]).map((r) => r.creators).filter(Boolean) };
}
