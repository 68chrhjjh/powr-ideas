import { NextRequest, NextResponse } from 'next/server';
import { randomUUID } from 'crypto';
import { z } from 'zod';
import { serviceClient } from '@/lib/service';
const hits = new Map<string, number[]>(); // per-instance limiter; see README for a durable one
export async function POST(req: NextRequest) {
  const ip = req.headers.get('x-forwarded-for')?.split(',')[0] ?? 'unknown';
  const now = Date.now(); const recent = (hits.get(ip) ?? []).filter((t) => now - t < 60_000);
  if (recent.length >= 30) return NextResponse.json({ error: 'rate_limited' }, { status: 429 });
  hits.set(ip, [...recent, now]);
  const body = z.object({ ideaId: z.string().uuid() }).safeParse(await req.json().catch(() => null));
  if (!body.success) return NextResponse.json({ error: 'invalid' }, { status: 400 });
  const vid = req.cookies.get('pi_vid')?.value ?? randomUUID();
  const { data, error } = await serviceClient().rpc('toggle_like', { p_idea: body.data.ideaId, p_visitor: vid });
  if (error || !data?.[0]) return NextResponse.json({ error: 'failed' }, { status: 400 });
  const res = NextResponse.json({ liked: data[0].out_liked, count: data[0].out_count });
  res.cookies.set('pi_vid', vid, { httpOnly: true, sameSite: 'lax', secure: true, maxAge: 31536000, path: '/' });
  return res;
}
