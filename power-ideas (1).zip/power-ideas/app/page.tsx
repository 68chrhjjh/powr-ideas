import Link from 'next/link';
import { getCreators, getIdeas } from '@/lib/data';
import { Logo } from '@/components/Logo';
import { Reveal } from '@/components/Reveal';
import { CreatorCard, IdeaCard, Empty } from '@/components/Cards';
export const revalidate = 60;
export default async function Home() {
  const [creators, ideas] = await Promise.all([getCreators(4), getIdeas(6)]);
  return (<>
    <section className="relative overflow-hidden border-b border-line">
      <div className="absolute inset-0 bg-[radial-gradient(60%_60%_at_80%_0%,rgba(205,24,31,.22),transparent)]" />
      <div className="relative mx-auto max-w-6xl px-5 py-28 md:py-40">
        <Logo className="mb-10 h-14 w-auto" />
        <h1 className="max-w-3xl text-4xl font-bold leading-tight md:text-6xl">أفكار فيديو جديدة، مكتوبة لصنّاع محتوى Power Esports</h1>
        <p className="mt-6 max-w-xl text-lg text-bone/70">اكتشف الأفكار المقترحة، افهم كيف تعمل، وتنقّل بينها وبين صنّاع المحتوى المستهدفين.</p>
        <div className="mt-10 flex flex-wrap gap-4">
          <Link href="/ideas" className="bg-accent px-7 py-3 font-bold text-white transition hover:brightness-110">استكشف الأفكار</Link>
          <Link href="/creators" className="border border-line px-7 py-3 transition hover:border-accent">اكتشف صنّاع المحتوى</Link></div>
      </div></section>
    <section className="mx-auto max-w-6xl px-5 pt-20"><h2 className="mb-8 text-2xl font-bold">صنّاع المحتوى</h2>
      {creators.length ? <div className="grid grid-cols-2 gap-4 md:grid-cols-4">{creators.map((c, i) => <Reveal key={c.id} delay={i * 0.08}><CreatorCard c={c} /></Reveal>)}</div> : <Empty text="لم تتم إضافة صنّاع محتوى بعد." />}</section>
    <section className="mx-auto max-w-6xl px-5 pt-20"><div className="mb-8 flex items-end justify-between"><h2 className="text-2xl font-bold">أحدث الأفكار</h2><Link href="/ideas" className="text-sm text-accentText">عرض كل الأفكار</Link></div>
      {ideas.length ? <div className="grid gap-5 md:grid-cols-3">{ideas.map((i, k) => <Reveal key={i.id} delay={(k % 3) * 0.08}><IdeaCard idea={i} /></Reveal>)}</div> : <Empty text="لا توجد أفكار منشورة بعد." />}</section>
    <section className="mx-auto mt-24 max-w-6xl border border-line px-5 py-16 text-center"><h2 className="text-3xl font-bold">ابدأ من الفكرة التي تعجبك</h2>
      <Link href="/ideas" className="mt-8 inline-block bg-accent px-8 py-3 font-bold text-white">تصفّح الأفكار</Link></section>
  </>);
}
