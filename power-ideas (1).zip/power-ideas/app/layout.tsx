import type { Metadata } from 'next';
import { IBM_Plex_Sans_Arabic } from 'next/font/google';
import Link from 'next/link';
import './globals.css';
import { Logo } from '@/components/Logo';
const font = IBM_Plex_Sans_Arabic({ subsets: ['arabic'], weight: ['400', '500', '700'], variable: '--font-ar' });
export const metadata: Metadata = {
  metadataBase: new URL(process.env.NEXT_PUBLIC_SITE_URL ?? 'http://localhost:3000'),
  title: { default: 'POWER IDEAS', template: '%s | POWER IDEAS' },
  description: 'أفكار فيديو مبتكرة مقترحة لصنّاع محتوى Power Esports.',
  openGraph: { locale: 'ar_AR', type: 'website', siteName: 'POWER IDEAS' } };
export default function Root({ children }: { children: React.ReactNode }) {
  return (<html lang="ar" dir="rtl" className={font.variable}><body>
    <header className="sticky top-0 z-30 border-b border-line bg-ink/85 backdrop-blur">
      <nav className="mx-auto flex h-16 max-w-6xl items-center justify-between px-5">
        <Link href="/" aria-label="POWER IDEAS"><Logo className="h-9 w-auto" /></Link>
        <div className="flex gap-6 text-sm"><Link href="/ideas" className="hover:text-accentText">الأفكار</Link><Link href="/creators" className="hover:text-accentText">صنّاع المحتوى</Link></div>
      </nav></header>
    <main>{children}</main>
    <footer className="mt-24 border-t border-line py-10 text-center text-sm text-bone/50">POWER IDEAS</footer>
  </body></html>);
}
