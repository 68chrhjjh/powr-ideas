import Link from 'next/link';
export default function NotFound() { return (<div className="mx-auto max-w-xl px-5 py-32 text-center"><h1 className="text-4xl font-bold">الصفحة غير موجودة</h1><p className="mt-4 text-bone/60">الرابط غير صحيح أو أن المحتوى لم يعد متاحًا.</p><Link href="/" className="mt-8 inline-block rounded-sm bg-accent px-6 py-3 font-bold text-white">العودة للرئيسية</Link></div>); }
