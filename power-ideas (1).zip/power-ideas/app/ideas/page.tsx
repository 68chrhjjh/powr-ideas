import { getIdeas } from '@/lib/data';
import { IdeaCard, Empty } from '@/components/Cards';
export const revalidate = 60; export const metadata = { title: 'الأفكار' };
export default async function Ideas() {
  const ideas = await getIdeas();
  return <div className="mx-auto max-w-6xl px-5 pt-16"><h1 className="mb-8 text-3xl font-bold">الأفكار</h1>
    {ideas.length ? <div className="grid gap-5 md:grid-cols-3">{ideas.map((i) => <IdeaCard key={i.id} idea={i} />)}</div> : <Empty text="لا توجد أفكار منشورة بعد." />}</div>;
}
