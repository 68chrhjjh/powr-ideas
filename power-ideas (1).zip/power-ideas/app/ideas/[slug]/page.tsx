import Image from 'next/image';
import Link from 'next/link';
import { cookies } from 'next/headers';
import { notFound } from 'next/navigation';
import { getIdea } from '@/lib/data';
import { serviceClient } from '@/lib/service';
import { LikeButton, ShareButton } from '@/components/Actions';
type P = { params: Promise<{ slug: string }> };
export async function generateMetadata({ params }: P) {
  const i = await getIdea((await params).slug); if (!i) return {};
  return { title: i.title, description: i.short_description, openGraph: { title: i.title, description: i.short_description, images: i.image_url ? [i.image_url] : [] } };
}
export default async function IdeaPage({ params }: P) {
  const idea = await getIdea((await params).slug); if (!idea) notFound();
  const vid = (await cookies()).get('pi_vid')?.value; let liked = false;
  if (vid) { const { data } = await serviceClient().from('idea_likes').select('id').eq('idea_id', idea.id).eq('visitor_id', vid).maybeSingle(); liked = !!data; }
  return (<article>
    <div className="relative h-[50vh] min-h-[320px] w-full bg-coal">{idea.image_url && <Image src={idea.image_url} alt={idea.title} fill priority sizes="100vw" className="object-cover" />}
      <div className="absolute inset-0 bg-gradient-to-t from-ink to-transparent" /></div>
    <div className="relative mx-auto -mt-24 max-w-3xl px-5">
      <h1 className="text-3xl font-bold leading-tight md:text-5xl">{idea.title}</h1>
      <p className="mt-3 text-sm text-bone/50">{new Date(idea.created_at).toLocaleDateString('ar')}</p>
      <div className="mt-6 flex gap-3"><LikeButton ideaId={idea.id} initialLiked={liked} initialCount={idea.like_count} /><ShareButton title={idea.title} /></div>
      <div className="mt-10 whitespace-pre-line text-lg leading-loose text-bone/85">{idea.full_description}</div>
      {idea.creators.length > 0 && <section className="mt-16"><h2 className="mb-5 text-2xl font-bold">صنّاع المحتوى المستهدفون</h2>
        <ul className="grid gap-3 sm:grid-cols-2">{idea.creators.map((c: any) => (<li key={c.id}><Link href={`/creators/${c.slug}`} className="flex items-center gap-4 border border-line bg-coal p-3 transition hover:border-accent">
          <span className="relative h-16 w-16 shrink-0 overflow-hidden bg-line">{c.image_url && <Image src={c.image_url} alt="" fill sizes="64px" className="object-cover" />}</span>
          <span><b className="block">{c.name}</b><span className="text-sm text-accentText">اكتشف صانع المحتوى</span></span></Link></li>))}</ul></section>}
    </div></article>);
}
