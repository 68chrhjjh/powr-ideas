import { getCreators } from '@/lib/data';
import { CreatorCard, Empty } from '@/components/Cards';
export const revalidate = 60; export const metadata = { title: 'صنّاع المحتوى' };
export default async function Creators() {
  const list = await getCreators();
  return <div className="mx-auto max-w-6xl px-5 pt-16"><h1 className="mb-8 text-3xl font-bold">صنّاع المحتوى</h1>
    {list.length ? <div className="grid grid-cols-2 gap-4 md:grid-cols-4">{list.map((c) => <CreatorCard key={c.id} c={c} />)}</div> : <Empty text="لم تتم إضافة صنّاع محتوى بعد." />}</div>;
}
