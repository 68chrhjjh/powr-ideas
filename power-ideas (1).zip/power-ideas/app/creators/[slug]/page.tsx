import Image from 'next/image';
import { notFound } from 'next/navigation';
import { ExternalLink } from 'lucide-react';
import { getCreator } from '@/lib/data';
import { IdeaCard, Empty } from '@/components/Cards';
export const revalidate = 60;
type P = { params: Promise<{ slug: string }> };
export async function generateMetadata({ params }: P) {
  const c = await getCreator((await params).slug); if (!c) return {};
  return { title: c.name, description: c.description ?? `أفكار مخصصة لـ ${c.name}`, openGraph: { images: c.image_url ? [c.image_url] : [] } };
}
export default async function CreatorPage({ params }: P) {
  const c = await getCreator((await params).slug); if (!c) notFound();
  return (<div className="mx-auto max-w-6xl px-5 pt-16">
    <div className="grid gap-10 md:grid-cols-[320px_1fr]">
      <div className="relative aspect-[3/4] overflow-hidden border border-line bg-coal">{c.image_url && <Image src={c.image_url} alt={c.name} fill priority sizes="320px" className="object-cover" />}</div>
      <div className="self-end"><h1 className="text-4xl font-bold md:text-5xl">{c.name}</h1>
        {c.description && <p className="mt-4 max-w-xl text-bone/70">{c.description}</p>}
        <p className="mt-4 text-accentText">{c.ideas.length} فكرة مقترحة</p>
        {c.channel_url && <a href={c.channel_url} target="_blank" rel="noopener noreferrer" className="mt-6 inline-flex items-center gap-2 bg-accent px-6 py-3 font-bold text-white"><ExternalLink size={18} />زيارة القناة</a>}</div></div>
    <h2 className="mb-6 mt-16 text-2xl font-bold">أفكار مخصصة لـ {c.name}</h2>
    {c.ideas.length ? <div className="grid gap-5 md:grid-cols-3">{c.ideas.map((i: any) => <IdeaCard key={i.id} idea={i} />)}</div> : <Empty text="لا توجد أفكار منشورة لهذا الصانع بعد." />}</div>);
}
