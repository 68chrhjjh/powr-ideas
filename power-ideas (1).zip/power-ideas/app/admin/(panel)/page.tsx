import { serviceClient } from '@/lib/service';
export const dynamic = 'force-dynamic';
export default async function Admin() { // route is gated by middleware.ts (admin role verified server-side)
  const sb = serviceClient();
  const [c, i, l] = await Promise.all([sb.from('creators').select('*', { count: 'exact', head: true }), sb.from('ideas').select('*', { count: 'exact', head: true }).eq('status', 'published'), sb.from('idea_likes').select('*', { count: 'exact', head: true })]);
  return <div className="mx-auto max-w-4xl px-5 pt-16"><h1 className="mb-8 text-3xl font-bold">لوحة التحكم</h1>
    <dl className="grid gap-4 sm:grid-cols-3">{[['صنّاع المحتوى', c.count], ['الأفكار المنشورة', i.count], ['الإعجابات', l.count]].map(([k, v]) => <div key={String(k)} className="border border-line bg-coal p-6"><dt className="text-bone/60">{k}</dt><dd className="mt-2 text-4xl font-bold">{v ?? 0}</dd></div>)}</dl></div>;
}
