'use client';
import { useState } from 'react';
import { useRouter } from 'next/navigation';
import { createBrowserClient } from '@supabase/ssr';
export default function Login() {
  const r = useRouter(); const [err, setErr] = useState('');
  async function submit(e: React.FormEvent<HTMLFormElement>) {
    e.preventDefault(); const f = new FormData(e.currentTarget);
    const sb = createBrowserClient(process.env.NEXT_PUBLIC_SUPABASE_URL!, process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY!);
    const { error } = await sb.auth.signInWithPassword({ email: String(f.get('email')), password: String(f.get('password')) });
    if (error) return setErr('بيانات الدخول غير صحيحة'); r.replace('/admin'); r.refresh();
  }
  return <form onSubmit={submit} className="mx-auto mt-24 max-w-sm space-y-4 px-5"><h1 className="text-2xl font-bold">دخول المشرف</h1>
    <input name="email" type="email" required placeholder="البريد الإلكتروني" className="w-full border border-line bg-coal p-3" />
    <input name="password" type="password" required placeholder="كلمة المرور" className="w-full border border-line bg-coal p-3" />
    {err && <p role="alert" className="text-red-400">{err}</p>}<button className="w-full bg-accent p-3 font-bold text-white">دخول</button></form>;
}
