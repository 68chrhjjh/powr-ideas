const host = process.env.NEXT_PUBLIC_SUPABASE_URL ? new URL(process.env.NEXT_PUBLIC_SUPABASE_URL).hostname : '*.supabase.co';
export default { images: { remotePatterns: [{ protocol: 'https', hostname: host, pathname: '/storage/v1/object/public/**' }] } };
