import type { Config } from 'tailwindcss';
export default { content: ['./app/**/*.{ts,tsx}', './components/**/*.{ts,tsx}'],
  theme: { extend: { colors: { ink: '#09090b', coal: '#131316', line: '#26262c', bone: '#ece7df', accent: 'var(--accent)', accentText: 'var(--accent-text)' } } },
  plugins: [] } satisfies Config;
