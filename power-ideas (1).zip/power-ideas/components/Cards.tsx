import Image from 'next/image';
import Link from 'next/link';
import { Heart } from 'lucide-react';
export function IdeaCard({ idea }: { idea: any }) {
  return (<Link href={`/ideas/${idea.slug}`} className="group block overflow-hidden border border-line bg-coal transition-colors hover:border-accent">
    <div className="relative aspect-video overflow-hidden bg-line">{idea.image_url && <Image src={idea.image_url} alt={idea.title} fill sizes="(min-width:768px) 33vw, 100vw" className="object-cover transition-transform duration-700 group-hover:scale-105" />}</div>
    <div className="p-5"><h3 className="text-lg font-bold leading-snug">{idea.title}</h3>
      <p className="mt-2 line-clamp-2 text-sm text-bone/60">{idea.short_description}</p>
      <span className="mt-4 flex items-center gap-1 text-xs text-bone/50"><Heart size={14} />{idea.like_count}</span></div></Link>);
}
export function CreatorCard({ c }: { c: any }) {
  const n = c.idea_creators?.[0]?.count ?? 0;
  return (<Link href={`/creators/${c.slug}`} className="group relative block aspect-[3/4] overflow-hidden border border-line bg-coal">
    {c.image_url && <Image src={c.image_url} alt={c.name} fill sizes="(min-width:768px) 25vw, 50vw" className="object-cover transition-transform duration-700 group-hover:scale-105" />}
    <div className="absolute inset-0 bg-gradient-to-t from-ink via-ink/20 to-transparent" />
    <div className="absolute inset-x-0 bottom-0 p-4"><h3 className="text-lg font-bold">{c.name}</h3><p className="text-xs text-accentText">{n} فكرة</p></div></Link>);
}
export const Empty = ({ text }: { text: string }) => <div className="border border-dashed border-line py-16 text-center text-bone/50">{text}</div>;
