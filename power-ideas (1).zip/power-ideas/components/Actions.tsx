'use client';
import { useState } from 'react';
import { Heart, Share2, Check } from 'lucide-react';
export function LikeButton({ ideaId, initialLiked, initialCount }: { ideaId: string; initialLiked: boolean; initialCount: number }) {
  const [s, setS] = useState({ liked: initialLiked, count: initialCount }); const [busy, setBusy] = useState(false);
  async function toggle() {
    if (busy) return; setBusy(true); const prev = s;
    setS({ liked: !s.liked, count: s.count + (s.liked ? -1 : 1) }); // optimistic
    try {
      const r = await fetch('/api/like', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ ideaId }) });
      if (!r.ok) throw new Error(); const d = await r.json(); setS({ liked: d.liked, count: d.count });
    } catch { setS(prev); } finally { setBusy(false); }
  }
  return <button onClick={toggle} aria-pressed={s.liked} className={`flex items-center gap-2 border px-5 py-3 transition active:scale-95 ${s.liked ? 'border-accent bg-accent text-white' : 'border-line hover:border-accent'}`}><Heart size={18} fill={s.liked ? 'currentColor' : 'none'} />{s.count}</button>;
}
export function ShareButton({ title }: { title: string }) {
  const [ok, setOk] = useState(false);
  async function share() {
    const url = location.href;
    if (navigator.share) { try { await navigator.share({ title, url }); return; } catch { /* cancelled */ } }
    await navigator.clipboard.writeText(url); setOk(true); setTimeout(() => setOk(false), 2000);
  }
  return <button onClick={share} className="flex items-center gap-2 border border-line px-5 py-3 transition hover:border-accent active:scale-95">{ok ? <Check size={18} /> : <Share2 size={18} />}{ok ? 'تم نسخ الرابط' : 'مشاركة'}</button>;
}
