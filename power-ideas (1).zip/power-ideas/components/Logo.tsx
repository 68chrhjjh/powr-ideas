import Image from 'next/image';
// Put the official logo at public/logo.png (not redrawn or altered here).
export function Logo({ className = '' }: { className?: string }) {
  return <Image src="/logo.png" alt="Power Esports" width={Math.round(160)} height={Math.round(160*0.3)} priority className={className} />;
}
